# Voice Control X — Android source project

**One-line explanation:** Voice Control X listens to a one-shot Hindi/English voice command and routes it to supported Android actions; commands are rule-based, and sensitive/system-restricted actions open the relevant settings or ask for user confirmation instead of bypassing Android security.

## Included
- Android Kotlin source project
- Speech recognition through Android `SpeechRecognizer`
- Hindi/English keyword routing
- Open supported apps (YouTube, WhatsApp, Chrome, Instagram, Maps, Settings, Phone, Messages where installed)
- Media search: commands such as `Honey Singh ka gaana chalao`, `YouTube par Honey Singh search karo`, `Play Arijit Singh Tum Hi Ho`
- Music volume up/down/mute using Android AudioManager
- WhatsApp message draft via `wa.me` (user chooses recipient and presses Send)
- Airplane-mode and internet settings shortcuts
- Accessibility service scaffold for future, user-enabled UI interactions
- GitHub Actions workflow to build a debug APK and upload it as an artifact

## Build on GitHub using a phone
1. Upload/replace the contents of this project in your GitHub repository. Keep the folder structure intact.
2. Confirm `.github/workflows/build.yml` is present on the repository's default branch.
3. Open **Actions → Build APK → Run workflow**.
4. Wait for the green **Success** result.
5. Open the run's **Artifacts** section and download the ZIP artifact. Extract it and install `app-debug.apk`.
6. Android may ask you to allow microphone access. Grant it only if you want to use voice recognition.
7. If you want to test the accessibility scaffold, open the app and use **Enable Accessibility**; enable it manually in Android Settings. This project does not secretly enable accessibility.

## Voice examples
- `YouTube kholo`
- `Honey Singh ka gaana chalao`
- `YouTube par Arijit Singh Tum Hi Ho search karo`
- `volume badhao` / `awaaz kam karo` / `mute`
- `WhatsApp kholo`
- `WhatsApp message bhejo main aa raha hoon` — opens a message draft; choose a recipient and press Send yourself.
- `flight mode` / `internet off` — opens Android settings because current Android versions restrict third-party apps from toggling these settings directly.

## Important limitations (not bugs that can be safely promised away)
- This is a starter project, not a universal assistant that can perform every action in every app. Android has no public API that lets an ordinary app control literally everything on the phone.
- YouTube search opens a search-results screen. Automatically selecting and playing a specific result inside YouTube requires Accessibility UI automation and varies with YouTube version, account state, ads, consent screens, and layout. The included accessibility service is a scaffold, not a guaranteed universal YouTube clicker.
- A command given while YouTube is already open is still routed by this app only while Voice Control X is listening. This version does not provide an always-listening background wake word or continuous global microphone capture.
- WhatsApp message sending requires selecting a recipient and confirming Send. This project does not send messages silently.
- Android restricts apps from directly toggling Airplane mode or mobile data on modern versions; the app opens the relevant settings instead.
- An ordinary app cannot unlock the phone by entering a user-provided PIN or bypass the lock screen. Unlock using the device's secure system UI.
- `getLaunchIntentForPackage` may not work for every manufacturer app/package name. Unsupported apps need explicit mappings or a safe Android app-picker flow.
- Google Play Protect may warn about a newly built/debug APK, especially when it requests Accessibility access. Review source and permissions; do not disable protection blindly.

## Security
- Never hard-code a lock-screen PIN, passwords, or account credentials in this app.
- Accessibility permission is powerful. Enable it only after reviewing the source and only if you understand the access it grants.
- Debug APK is for testing, not a signed Play Store release.
