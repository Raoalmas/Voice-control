package com.voicecontrolx.app

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import java.net.URLEncoder
import java.util.Locale

/** Rule-based, transparent command router. It deliberately asks the user to confirm sensitive actions. */
object CommandEngine {
    fun execute(context: Context, raw: String) {
        val original = raw.trim()
        val c = original.lowercase(Locale.ROOT)
        if (c.isBlank()) return

        when {
            isVolumeDown(c) -> changeVolume(context, -1)
            isVolumeUp(c) -> changeVolume(context, 1)
            isVolumeMute(c) -> setMute(context)
            isAirplane(c) -> openSettings(context, Settings.ACTION_AIRPLANE_MODE_SETTINGS,
                "Android does not allow ordinary apps to toggle Airplane mode directly. Use the setting opened here.")
            isInternet(c) -> openSettings(context, Settings.ACTION_WIRELESS_SETTINGS,
                "Android restricts direct mobile-data/Wi-Fi toggles. Use the settings opened here.")
            isWhatsAppMessage(c) -> prepareWhatsAppMessage(context, original)
            isYouTubePlay(c) -> searchYouTube(context, extractMediaQuery(original))
            isYouTubeOpen(c) -> openAppOrWeb(context, "com.google.android.youtube", "https://www.youtube.com", "YouTube")
            isAppOpen(c) -> {
                val target = extractAppTarget(original)
                val mapping = appMapping(target)
                if (mapping != null) openAppOrWeb(context, mapping.first, mapping.second, target)
                else toast(context, "App mapping nahi mila: $target. App ka exact naam bolkar try karein.")
            }
            c.contains("screen unlock") || c.contains("unlock screen") || c.contains("स्क्रीन अनलॉक") || c.contains("फोन अनलॉक") ->
                toast(context, "Security ke liye app PIN/lock-screen bypass nahi kar sakta. Phone ka official unlock method use karein.")
            else -> toast(context, "Command abhi supported nahi hai: \"$original\". Supported commands README mein hain.")
        }
    }

    private fun isVolumeDown(c: String) = listOf("volume down", "lower volume", " आवाज कम", "आवाज कम", "आवाज़ कम", "वॉल्यूम कम", "volume kam", "कम आवाज").any(c::contains)
    private fun isVolumeUp(c: String) = listOf("volume up", "increase volume", "आवाज बढ़ा", "आवाज़ बढ़ा", "वॉल्यूम बढ़ा", "volume badha", "आवाज ज्यादा", "आवाज़ ज्यादा", "volume zyada").any(c::contains)
    private fun isVolumeMute(c: String) = listOf("mute", "आवाज बंद", "आवाज़ बंद", "वॉल्यूम म्यूट").any(c::contains)
    private fun isAirplane(c: String) = listOf("airplane mode", "flight mode", "फ्लाइट मोड", "एयरप्लेन मोड").any(c::contains)
    private fun isInternet(c: String) = listOf("internet on", "internet off", "mobile data", "wifi on", "wifi off", "इंटरनेट ऑन", "इंटरनेट ऑफ", "वाईफाई ऑन", "वाईफाई ऑफ", "मोबाइल डेटा").any(c::contains)
    private fun isYouTubeOpen(c: String) = (c.contains("youtube") || c.contains("यूट्यूब")) && listOf("open", "खोल", "खोलो", "ओपन", "चालू").any(c::contains)

    private fun isYouTubePlay(c: String): Boolean {
        val mediaVerb = listOf("play", "चलाओ", "चलाना", "बजाओ", "सुनाओ", "song", "गाना", "वीडियो", "video", "search", "ढूंढ", "खोजो").any(c::contains)
        val appMention = c.contains("youtube") || c.contains("यूट्यूब")
        // A media command without an app name defaults to YouTube, so it won't be misreported as an unknown app.
        return mediaVerb && (appMention || listOf("गाना", "song", "वीडियो", "video", "चलाओ", "बजाओ", "सुनाओ").any(c::contains))
    }

    private fun isAppOpen(c: String) = listOf("open ", "launch ", "खोलो", "खोल", "ओपन", "चालू करो", "खोल देना").any(c::contains)

    private fun isWhatsAppMessage(c: String) = (c.contains("whatsapp") || c.contains("व्हाट्सएप") || c.contains("वॉट्सऐप")) &&
        listOf("message", "msg", "मैसेज", "संदेश", "भेजो", "भेजना").any(c::contains)

    private fun changeVolume(context: Context, direction: Int) {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,
            if (direction > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI)
    }
    private fun setMute(context: Context) {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
    }

    private fun searchYouTube(context: Context, query: String) {
        val q = query.ifBlank { "trending songs" }
        val uri = Uri.parse("https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8"))
        val appIntent = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.youtube").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { context.startActivity(appIntent) }
        catch (_: Exception) {
            try { context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (_: Exception) { toast(context, "YouTube/search app open nahi ho saka.") }
        }
        toast(context, "YouTube par search khol raha hoon: $q. Playback/result selection YouTube UI par depend karta hai.")
    }

    private fun extractMediaQuery(raw: String): String {
        return raw.replace(Regex("(?i)youtube|यूट्यूब|open|launch|play|search|song|video|music|please|the|on|in|for"), " ")
            .replace(Regex("खोलो|खोल|ओपन|चलाओ|चलाना|बजाओ|सुनाओ|गाना|वीडियो|खोजो|ढूंढो|चलाना है|में|पर|को|कोई|एक"), " ")
            .replace(Regex("\\s+"), " ").trim().ifBlank { raw.trim() }
    }

    private fun extractAppTarget(raw: String): String = raw
        .replace(Regex("(?i)open|launch|please|app|application"), " ")
        .replace(Regex("खोलो|खोल|ओपन|चालू करो|खोल देना|ऐप|एप्लीकेशन"), " ")
        .replace(Regex("\\s+"), " ").trim()

    private fun appMapping(target: String): Pair<String, String>? {
        val t = target.lowercase(Locale.ROOT)
        return when {
            t.contains("youtube") || t.contains("यूट्यूब") -> "com.google.android.youtube" to "https://www.youtube.com"
            t.contains("whatsapp") || t.contains("व्हाट्सएप") || t.contains("वॉट्सऐप") -> "com.whatsapp" to "https://www.whatsapp.com"
            t.contains("chrome") || t.contains("क्रोम") -> "com.android.chrome" to "https://www.google.com/chrome/"
            t.contains("instagram") || t.contains("इंस्टाग्राम") -> "com.instagram.android" to "https://www.instagram.com"
            t.contains("maps") || t.contains("मैप") || t.contains("नक्शा") -> "com.google.android.apps.maps" to "https://maps.google.com"
            t.contains("camera") || t.contains("कैमरा") -> "com.android.camera" to ""
            t.contains("settings") || t.contains("सेटिंग") -> "com.android.settings" to ""
            t.contains("phone") || t.contains("dialer") || t.contains("फोन") -> "com.google.android.dialer" to ""
            t.contains("messages") || t.contains("sms") || t.contains("मैसेज") -> "com.google.android.apps.messaging" to ""
            else -> null
        }
    }

    private fun openAppOrWeb(context: Context, packageName: String, fallbackUrl: String, label: String) {
        try {
            val launch = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            else if (fallbackUrl.isNotBlank()) context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            else toast(context, "$label installed nahi hai ya launch intent available nahi hai.")
        } catch (_: ActivityNotFoundException) { toast(context, "$label open nahi ho saka.") }
        catch (_: Exception) { toast(context, "$label open nahi ho saka.") }
    }

    private fun prepareWhatsAppMessage(context: Context, raw: String) {
        val body = raw.replace(Regex("(?i).*?(whatsapp|व्हाट्सएप|वॉट्सऐप)"), " ")
            .replace(Regex("(?i)message|msg|मैसेज|संदेश|भेजो|भेजना|भाई को|भाई"), " ")
            .replace(Regex("\\s+"), " ").trim()
        val url = "https://wa.me/?text=" + URLEncoder.encode(body.ifBlank { "" }, "UTF-8")
        try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { toast(context, "WhatsApp message screen open nahi ho saka.") }
        toast(context, "Message draft khul raha hai. Recipient choose karke Send dabayein; app bina confirmation message nahi bhejega.")
    }

    private fun openSettings(context: Context, action: String, message: String) {
        try { context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { toast(context, message) }
        toast(context, message)
    }
    private fun toast(context: Context, message: String) = Toast.makeText(context, message, Toast.LENGTH_LONG).show()
}
