package com.voicecontrolx.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.net.URLEncoder
import java.util.Locale

object CommandEngine {
    fun execute(context: Context, raw: String) {
        val command = raw.trim().lowercase(Locale.getDefault())

        when {
            isYouTubeCommand(command) -> handleYouTube(context, raw)
            command.contains("open youtube") || command.contains("youtube kholo") ||
            command.contains("youtube khol") || command.contains("यूट्यूब खोल") ||
            command.contains("यूट्यूब चालू") -> openYouTube(context)
            command.startsWith("open ") || command.startsWith("launch ") ||
            command.startsWith("खोलो ") || command.startsWith("खोल ") -> {
                val target = raw.replaceFirst(Regex("(?i)^(open|launch)\\s+"), "")
                    .replaceFirst(Regex("^(खोलो|खोल)\\s+"), "").trim()
                openKnownApp(context, target)
            }
            else -> Toast.makeText(context, "Command understood, but no action handler exists yet.", Toast.LENGTH_LONG).show()
        }
    }

    private fun isYouTubeCommand(c: String): Boolean {
        val hasYoutube = c.contains("youtube") || c.contains("यूट्यूब")
        val action = listOf("play", "चलाओ", "चलाना", "गाना", "song", "video", "वीडियो", "search", "खोज", "ढूंढ").any { c.contains(it) }
        return hasYoutube && action
    }

    private fun handleYouTube(context: Context, raw: String) {
        val cleaned = raw
            .replace(Regex("(?i)youtube"), "")
            .replace("यूट्यूब", "")
            .replace(Regex("(?i)\\b(open|play|search|चलाओ|चलाना|खोलो|खोल|गाना|song|video|वीडियो|में|पर|को)\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val query = if (cleaned.isBlank()) "YouTube" else cleaned
        val encoded = URLEncoder.encode(query, "UTF-8")
        val uri = Uri.parse("https://www.youtube.com/results?search_query=$encoded")
        try {
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.google.android.youtube")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        Toast.makeText(context, "YouTube search opened: $query", Toast.LENGTH_SHORT).show()
    }

    private fun openYouTube(context: Context) {
        try {
            context.startActivity(
                context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                    ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            Toast.makeText(context, "YouTube is not installed.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openKnownApp(context: Context, target: String) {
        val t = target.lowercase(Locale.getDefault())
        val pkg = when {
            t.contains("youtube") || t.contains("यूट्यूब") -> "com.google.android.youtube"
            t.contains("whatsapp") || t.contains("व्हाट्सएप") -> "com.whatsapp"
            t.contains("chrome") -> "com.android.chrome"
            t.contains("instagram") || t.contains("इंस्टाग्राम") -> "com.instagram.android"
            else -> null
        }
        if (pkg == null) {
            Toast.makeText(context, "I don't have a safe app mapping for: $target", Toast.LENGTH_LONG).show()
            return
        }
        val intent = context.packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        else Toast.makeText(context, "App not installed: $target", Toast.LENGTH_LONG).show()
    }
}
