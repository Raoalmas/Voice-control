package com.voicecontrolx.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class VoiceAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            flags = flags or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_CLICKED
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // The service is intentionally passive. It exposes a safe UI-action layer for
        // future command steps and avoids blindly clicking unrelated controls.
    }

    override fun onInterrupt() {}

    fun findAndClick(texts: List<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNode(root, texts) ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    fun findAndSetText(text: String, hints: List<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNode(root, hints) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findNode(root: AccessibilityNodeInfo, candidates: List<String>): AccessibilityNodeInfo? {
        val wanted = candidates.map { it.lowercase() }
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            val label = listOfNotNull(n.text?.toString(), n.contentDescription?.toString())
                .joinToString(" ").lowercase()
            if (wanted.any { label.contains(it) }) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let(queue::add)
        }
        return null
    }
}
