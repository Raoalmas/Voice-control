# Voice Control X

## One-line explanation
Voice Control X = voice-to-text + command parser + safe app launcher + optional Android Accessibility Service for user-requested UI actions.

## Important behavior
The app is designed so a command is not treated as complete just because an app opens. For YouTube commands it extracts the search/play phrase and opens a YouTube search URL. The Accessibility Service is included as the controlled UI-action layer for future multi-step interaction with an already-open app.

Examples:
- "YouTube kholo" -> opens YouTube.
- "YouTube par Arijit Singh ka song search karo" -> opens YouTube search for the extracted phrase.
- "YouTube par funny cat videos kholo" -> opens a YouTube search for the phrase.
- "WhatsApp kholo" -> opens WhatsApp when installed.

## Critical limitation
Android does not provide a stable public API that lets an ordinary app control every internal YouTube button. YouTube UI labels/layouts can change. Therefore this project does NOT pretend that every "play first result" action is guaranteed on every YouTube version.

For true multi-step UI automation, the Accessibility Service must be explicitly enabled by the user in Android Settings. It should only perform actions that the user requested. A production release should also have a clear accessibility disclosure and privacy policy.

## Build on GitHub
1. Push this project to a GitHub repository.
2. Open Actions.
3. Select `Build APK`.
4. Tap `Run workflow`.
5. Wait for Success.
6. Open the run and download artifact `voice-control-x-apk`.
7. Extract the ZIP and install `app-debug.apk` for testing.

## Android setup
1. Install the APK.
2. Open Voice Control X.
3. Allow microphone permission.
4. Tap `ENABLE ACCESSIBILITY`.
5. Android Settings -> Accessibility -> Voice Control X -> Enable.
6. Return to the app.
7. Tap LISTEN and speak a command.

## Why the old version failed
Opening YouTube and then stopping is not enough. A multi-step command needs:
speech recognition -> intent classification -> command extraction -> app launch -> wait for target UI -> UI action -> verification/fallback.

This project separates those responsibilities so future UI automation can be added without rewriting speech recognition.

## Safety
This app intentionally does not request SMS, contacts, phone-call, storage, or financial permissions. The only runtime permission is microphone. Accessibility is a special Android capability and must be enabled by the user.
