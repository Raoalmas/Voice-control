APK बनाने के 2 तरीके
A) Android Studio: इस फ़ोल्डर को Open करें -> Build > Build APK.
B) बिना कंप्यूटर के: GitHub पर नया repo बनाएँ, इस फ़ोल्डर की सारी फ़ाइलें (.github समेत) upload करें ->
   Actions टैब > Build APK > Run workflow -> पूरा होने पर Artifacts से app-debug.apk डाउनलोड करें।
फ़ोन पर APK खोलें -> "Install unknown apps" की अनुमति दें -> इंस्टॉल -> ऐप खोलें।
ज़रूरी नोट: Accessibility स्विच ग्रे हो तो Settings > Apps > Voice Control > ⋮ > "Allow restricted settings" चालू करें।
