package com.example.voicecontrol

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.widget.Toast

class VoiceService : Service() {
    companion object { var active = false }
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var wake = "मेरे दोस्त"
    private var awakeUntil = 0L
    private var running = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        wake = i?.getStringExtra("wake") ?: wake
        val ch = "voice"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Voice", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("सुन रहा हूँ")
            .setContentText("बोलो: $wake")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        running = true
        active = true
        listen()
        return START_STICKY
    }

    private fun listen() {
        if (!running) return
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it) }
                    h.postDelayed({ listen() }, 300)
                }
                override fun onError(e: Int) {
                    h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        sr?.startListening(i)
    }

    private fun handle(text: String) {
        val pattern = wake.filter { !it.isWhitespace() }
            .map { Regex.escape(it.toString()) }.joinToString("\\s*")
        val m = Regex(pattern, RegexOption.IGNORE_CASE).find(text)
        val rest = when {
            m != null -> text.substring(m.range.last + 1)
            System.currentTimeMillis() < awakeUntil -> text
            else -> return
        }
        if (rest.isBlank()) {
            awakeUntil = System.currentTimeMillis() + 8000
            Toast.makeText(this, "हाँ बोलो… 👂", Toast.LENGTH_SHORT).show()
            return
        }
        awakeUntil = 0
        Toast.makeText(this, "सुना: $rest", Toast.LENGTH_SHORT).show()
        CommandParser.run(this, CommandParser.parse(rest))
    }

    override fun onDestroy() {
        running = false
        active = false
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        super.onDestroy()
    }
}
