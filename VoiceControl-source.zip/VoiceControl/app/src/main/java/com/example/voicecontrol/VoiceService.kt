package com.example.voicecontrol

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.speech.*
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast

class VoiceService : Service() {
    companion object { var active = false }

    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var wake = "मेरे दोस्त"
    private var awakeUntil = 0L
    private var running = false
    private var overlay: View? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        wake = i?.getStringExtra("wake") ?: wake
        val ch = "voice"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Voice", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("सुन रहा हूँ")
            .setContentText("बोलो: $wake")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        addOverlay()
        running = true
        active = true
        listen()
        return START_STICKY
    }

    // 1 पिक्सल की अदृश्य विंडो: इससे Android बैकग्राउंड से ऐप खोलने देता है
    private fun addOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return
        val v = View(this)
        val lp = WindowManager.LayoutParams(1, 1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp); overlay = v } catch (_: Exception) {}
    }

    private fun listen() {
        if (!running) return
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it) }
                    h.postDelayed({ listen() }, 300)
                }
                override fun onError(e: Int) {
                    h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        sr?.startListening(i)
    }

    private fun norm(s: String) = s.lowercase().replace("\u093C", "").replace("\u0901", "\u0902")
        .filter { !it.isWhitespace() && it !in ",.।?!-'\"" }

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]; dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    // नाम (या कॉमा से अलग कई वर्तनी) लगभग मिलने पर भी पकड़ लेता है, जैसे "शेर" ≈ "शेयर"
    private fun matchWake(text: String): String? {
        val toks = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        for (wk in wake.split(",").map { it.trim() }.filter { it.isNotEmpty() }) {
            val w = norm(wk)
            val n = wk.split(Regex("\\s+")).size
            val tol = maxOf(1, w.length / 3)
            for (start in 0..minOf(2, toks.size - 1))
                for (len in maxOf(1, n - 1)..n + 1) {
                    if (start + len > toks.size) continue
                    if (lev(norm(toks.subList(start, start + len).joinToString(" ")), w) <= tol)
                        return toks.drop(start + len).joinToString(" ")
                }
        }
        return null
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun handle(text: String) {
        val m = matchWake(text)
        val rest = when {
            m != null -> m
            System.currentTimeMillis() < awakeUntil -> text
            else -> { toast("सुना (नाम नहीं मिला): $text"); return }
        }
        if (rest.isBlank()) {
            awakeUntil = System.currentTimeMillis() + 8000
            toast("हाँ बोलो… 👂")
            return
        }
        awakeUntil = 0
        toast("सुना: $rest")
        CommandParser.run(this, CommandParser.parse(rest))
    }

    override fun onDestroy() {
        running = false
        active = false
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        overlay?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }
}
