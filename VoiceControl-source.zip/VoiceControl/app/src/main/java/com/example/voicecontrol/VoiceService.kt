package com.example.voicecontrol

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.speech.*
import android.telephony.TelephonyManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class VoiceService : Service() {
    companion object { var active = false }

    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var wake = "मेरे दोस्त"
    private var awakeUntil = 0L
    private var running = false
    private var overlay: View? = null
    private var lastEvent = 0L
    private val watchdog = object : Runnable {
        override fun run() {
            if (!running) return
            if (SystemClock.elapsedRealtime() - lastEvent > 15000) { newRecognizer(); startRec() }
            h.postDelayed(this, 10000)
        }
    }

    private val recIntent by lazy {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            .putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("en-IN"))
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 800L)
    }

    // आने वाली कॉल का नाम बोलकर बताता है
    private val phoneRx = object : BroadcastReceiver() {
        private var last: String? = null
        override fun onReceive(c: Context, i: Intent) {
            if (i.getStringExtra(TelephonyManager.EXTRA_STATE) == TelephonyManager.EXTRA_STATE_RINGING) {
                val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: return
                if (num == last) return
                last = num
                Speaker.say(c, "कॉल आ रही है: " + PhoneInfo.nameFor(c, num))
            } else last = null
        }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(b: Bundle?) {
            lastEvent = SystemClock.elapsedRealtime()
            val l = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!l.isNullOrEmpty()) handle(l)
            h.post { startRec() }
        }
        override fun onError(e: Int) {
            lastEvent = SystemClock.elapsedRealtime()
            if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) h.post { startRec() }
            else h.postDelayed({ newRecognizer(); startRec() }, 700)
        }
        override fun onReadyForSpeech(p: Bundle?) { lastEvent = SystemClock.elapsedRealtime() }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(b: Bundle?) {}
        override fun onEvent(t: Int, b: Bundle?) {}
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Speaker.init(this)
        val f = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(phoneRx, f, Context.RECEIVER_EXPORTED)
            else registerReceiver(phoneRx, f)
        } catch (_: Exception) {}
    }

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        wake = i?.getStringExtra("wake") ?: wake
        val ch = "voice"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Voice", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("सुन रहा हूँ")
            .setContentText("बोलो: $wake")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        addOverlay()
        running = true
        active = true
        newRecognizer()
        startRec()
        lastEvent = SystemClock.elapsedRealtime()
        h.removeCallbacks(watchdog)
        h.postDelayed(watchdog, 10000)
        return START_STICKY
    }

    // 1 पिक्सल की अदृश्य विंडो: इससे Android बैकग्राउंड से ऐप खोलने देता है
    private fun addOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return
        val v = View(this)
        val lp = WindowManager.LayoutParams(1, 1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp); overlay = v } catch (_: Exception) {}
    }

    private fun newRecognizer() {
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
    }

    private fun startRec() {
        if (!running) return
        if (sr == null) newRecognizer()
        try { sr?.startListening(recIntent) }
        catch (e: Exception) { h.postDelayed({ newRecognizer(); startRec() }, 700) }
    }

    private fun norm(s: String) = s.lowercase().replace("\u093C", "").replace("\u0901", "\u0902")
        .filter { !it.isWhitespace() && it !in ",.।?!-'\"" }

    // नाम (या कॉमा से अलग कई वर्तनी) लगभग मिलने पर भी पकड़ लेता है, जैसे "शेर" ≈ "शेयर".
    // दो शब्द के नाम में सिर्फ़ आख़िरी शब्द ("दोस्त") भी चलता है।
    private fun matchWake(text: String): String? {
        val toks = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val variants = wake.split(",").map { it.trim() }.filter { it.isNotEmpty() }.flatMap { w ->
            val words = w.split(Regex("\\s+"))
            if (words.size > 1 && words.last().length >= 3) listOf(w, words.last()) else listOf(w)
        }
        for (wk in variants) {
            val w = norm(wk)
            val n = wk.split(Regex("\\s+")).size
            val tol = maxOf(1, w.length / 3)
            for (start in 0..minOf(2, toks.size - 1))
                for (len in maxOf(1, n - 1)..n + 1) {
                    if (start + len > toks.size) continue
                    if (Phonetic.lev(norm(toks.subList(start, start + len).joinToString(" ")), w) <= tol)
                        return toks.drop(start + len).joinToString(" ")
                }
        }
        return null
    }

    // नाम सुने बिना कुछ नहीं करता: न संदेश, न कमांड। बाकी बातें चुपचाप छोड़ दी जाती हैं।
    private fun handle(alts: List<String>) {
        val hit = alts.firstNotNullOfOrNull { matchWake(it) }
        val rest = hit ?: if (System.currentTimeMillis() < awakeUntil) alts[0] else return
        if (rest.isBlank()) {
            awakeUntil = System.currentTimeMillis() + 8000
            Speaker.say(this, "हाँ बोलो")
            return
        }
        awakeUntil = 0
        val steps = CommandParser.parse(rest)
        if (steps.isEmpty()) Speaker.say(this, "समझ नहीं आया")
        else CommandParser.run(this, steps)
    }

    override fun onDestroy() {
        running = false
        active = false
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        try { unregisterReceiver(phoneRx) } catch (_: Exception) {}
        Speaker.shutdown()
        overlay?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }
}
