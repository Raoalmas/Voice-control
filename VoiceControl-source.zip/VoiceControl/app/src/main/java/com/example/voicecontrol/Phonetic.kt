package com.example.voicecontrol

// हिंदी और अंग्रेज़ी दोनों को एक जैसी "व्यंजन-छाप" में बदलता है, ताकि
// "इंस्टाग्राम" == "Instagram", "सलमान" == "Salman" मिल सकें।
object Phonetic {
    private val hi = HashMap<Char, Char>().apply {
        "कख".forEach { put(it, 'k') }; "गघ".forEach { put(it, 'g') }
        "ङञणन".forEach { put(it, 'n') }; "चछ".forEach { put(it, 'k') }
        "जझ".forEach { put(it, 'j') }; "टठतथ".forEach { put(it, 't') }
        "डढदध".forEach { put(it, 'd') }; "पफ".forEach { put(it, 'p') }
        "बभ".forEach { put(it, 'b') }; "शषस".forEach { put(it, 's') }
        put('म', 'm'); put('य', 'y'); put('र', 'r'); put('ल', 'l'); put('ळ', 'l')
        put('व', 'v'); put('ह', 'h'); put('ं', 'n'); put('ँ', 'n')
    }

    fun skel(input: String): String {
        var t = input.lowercase()
        for ((a, b) in listOf("ph" to "p", "sh" to "s", "ch" to "c", "kh" to "k", "gh" to "g",
            "th" to "t", "dh" to "d", "bh" to "b", "ck" to "k")) t = t.replace(a, b)
        val sb = StringBuilder()
        var last: Char? = null
        for (ch in t) {
            if (ch == '\u094D') continue            // हलंत: पारदर्शी
            var m: Char? = hi[ch] ?: when (ch) {
                'b', 'd', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'r', 's', 't', 'v', 'y' -> ch
                'c', 'q' -> 'k'
                'f' -> 'p'
                'w' -> 'v'
                'z' -> 'j'
                in '0'..'9' -> ch
                else -> null
            }
            if (m == 'y' && sb.isNotEmpty()) m = null  // शब्द के बीच का y/य हटाओ (Paytm = पेटीएम)
            if (m == null) { last = null; if (ch == 'x') { sb.append("ks") }; continue }
            if (last != m) sb.append(m)
            last = m
        }
        return sb.toString()
    }

    fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]; dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    fun <T> best(q: String, items: List<Pair<T, String>>): T? {
        if (q.length < 2) return null
        var bestItem: T? = null
        var bestScore = Int.MAX_VALUE
        val tol = when { q.length <= 3 -> 0; q.length <= 6 -> 1; else -> 2 }
        for ((item, sk) in items) {
            if (sk.length < 2) continue
            val d = lev(q, sk)
            val score = when {
                sk == q -> 0
                d <= tol -> d
                sk.length >= 3 && q.contains(sk) -> 10 + (q.length - sk.length)
                sk.contains(q) -> 5 + (sk.length - q.length)
                else -> Int.MAX_VALUE
            }
            if (score < bestScore) { bestScore = score; bestItem = item }
        }
        return bestItem
    }
}
