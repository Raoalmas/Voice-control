package com.example.voicecontrol

import android.content.Context
import android.speech.tts.TextToSpeech
import android.widget.Toast
import java.util.Locale

object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false

    fun init(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("hi", "IN"))
                ready = true
            }
        }
    }

    fun say(ctx: Context, text: String) {
        Toast.makeText(ctx.applicationContext, text, Toast.LENGTH_SHORT).show()
        if (ready) tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "vc")
    }

    fun shutdown() { tts?.shutdown(); tts = null; ready = false }
}
