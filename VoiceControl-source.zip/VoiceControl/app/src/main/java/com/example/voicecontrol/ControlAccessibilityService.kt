package com.example.voicecontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class ControlAccessibilityService : AccessibilityService() {
    companion object { var instance: ControlAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun goFullscreen() {
        // 1) अगर फुल-स्क्रीन बटन दिख रहा है तो उसे दबाओ
        val labels = listOf("Enter fullscreen", "Full screen", "फ़ुल स्क्रीन", "फ़ुलस्क्रीन")
        for (l in labels) {
            val n = rootInActiveWindow?.findAccessibilityNodeInfosByText(l)?.firstOrNull()
            if (n != null) {
                var node = n
                while (node != null && !node.isClickable) node = node.parent
                if (node?.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK) == true) return
            }
        }
        // 2) नहीं तो प्लेयर पर ऊपर की तरफ़ स्वाइप (YouTube में इससे फुल स्क्रीन होता है)
        val dm = resources.displayMetrics
        val videoH = dm.widthPixels * 9f / 16f
        val x = dm.widthPixels / 2f
        val path = Path().apply {
            moveTo(x, 80f + videoH * 0.8f)
            lineTo(x, 80f + videoH * 0.2f)
        }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 250)).build(), null, null)
    }
}
