package com.example.voicecontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ControlAccessibilityService : AccessibilityService() {
    companion object { var instance: ControlAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 80)).build(), null, null)
    }

    fun goFullscreen() {
        // 1) अगर फुल-स्क्रीन बटन दिख रहा है तो उसे दबाओ
        val labels = listOf("Enter fullscreen", "Full screen", "फ़ुल स्क्रीन", "फ़ुलस्क्रीन")
        for (l in labels) {
            val n = rootInActiveWindow?.findAccessibilityNodeInfosByText(l)?.firstOrNull()
            if (n != null) {
                var node: AccessibilityNodeInfo? = n
                while (node != null && !node.isClickable) node = node.parent
                if (node?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return
            }
        }
        // 2) नहीं तो प्लेयर पर ऊपर की तरफ़ स्वाइप (YouTube में इससे फुल स्क्रीन होता है)
        val dm = resources.displayMetrics
        val videoH = dm.widthPixels * 9f / 16f
        val x = dm.widthPixels / 2f
        val path = Path().apply {
            moveTo(x, 80f + videoH * 0.8f)
            lineTo(x, 80f + videoH * 0.2f)
        }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 250)).build(), null, null)
    }

    // स्क्रीन पर ऊपर से गिनकर n-वाँ वीडियो खोलता है (YouTube की सूची में)
    fun pickVideo(n: Int) {
        val root = rootInActiveWindow
        if (root == null) { Speaker.say(this, "स्क्रीन नहीं पढ़ पाया"); return }
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val hh = dm.heightPixels
        val found = mutableListOf<Pair<Rect, AccessibilityNodeInfo>>()
        fun walk(node: AccessibilityNodeInfo?) {
            if (node == null) return
            if (node.isClickable) {
                val r = Rect(); node.getBoundsInScreen(r)
                val d = node.contentDescription?.toString()?.lowercase() ?: ""
                val big = r.width() >= w * 0.8 && r.height() >= w * 0.3
                val vid = r.width() >= w * 0.5 &&
                    (d.contains("play video") || d.contains("views") || d.contains("minutes") || d.contains("बार देखा"))
                if (r.top > hh * 0.08 && r.bottom <= hh && (big || vid)) found.add(r to node)
            }
            for (i in 0 until node.childCount) walk(node.getChild(i))
        }
        walk(root)
        val uniq = mutableListOf<Pair<Rect, AccessibilityNodeInfo>>()
        for (p in found.sortedBy { it.first.top })
            if (uniq.isEmpty() || p.first.top - uniq.last().first.top > 150) uniq.add(p)
        if (uniq.size < n) { Speaker.say(this, "स्क्रीन पर सिर्फ़ ${uniq.size} वीडियो दिख रहे हैं"); return }
        val (r, node) = uniq[n - 1]
        Speaker.say(this, "$n नंबर वीडियो चला रहा हूँ")
        if (!node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) tap(r.centerX().toFloat(), r.centerY().toFloat())
    }
}
