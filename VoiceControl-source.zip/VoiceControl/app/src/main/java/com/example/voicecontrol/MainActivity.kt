package com.example.voicecontrol

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var name: EditText
    private val asked = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        name = EditText(this).apply { hint = "नाम; कई वर्तनी कॉमा से: शेर, शेयर"; setText(prefs.getString("wake", "मेरे दोस्त")) }
        status = TextView(this).apply { textSize = 16f; setPadding(0, 30, 0, 30) }
        val go = Button(this).apply {
            text = "✅ नाम सेव करके चालू करें"
            setOnClickListener {
                prefs.edit().putString("wake", name.text.toString().trim().ifEmpty { "मेरे दोस्त" }).apply()
                asked.clear(); stopService(Intent(this@MainActivity, VoiceService::class.java)); step()
            }
        }
        val stop = Button(this).apply {
            text = "⏹ रोकें"
            setOnClickListener { stopService(Intent(this@MainActivity, VoiceService::class.java)); status.text = "बंद है" }
        }
        listOf(name, go, status, stop).forEach { root.addView(it) }
        setContentView(root)
    }

    override fun onResume() { super.onResume(); step() }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); step()
    }

    private fun accEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(packageName) && s.contains("ControlAccessibilityService")
    }

    private fun step() {
        val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS, Manifest.permission.POST_NOTIFICATIONS)
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        when {
            missing.isNotEmpty() -> {
                if (asked.add("perm")) requestPermissions(missing.toTypedArray(), 1)
                else status.text = "⚠ अनुमतियाँ बाकी हैं (माइक ज़रूरी है)। ऊपर का बटन दबाकर दोबारा कोशिश करें।"
            }
            !Settings.canDrawOverlays(this) -> {
                if (asked.add("overlay")) {
                    Toast.makeText(this, "इस ऐप के लिए स्विच चालू करें", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else status.text = "⚠ 'दूसरे ऐप के ऊपर दिखाएँ' चालू करना बाकी है।"
            }
            !accEnabled() -> {
                if (asked.add("acc")) {
                    Toast.makeText(this, "Voice Control चुनकर चालू करें", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } else status.text = "⚠ Accessibility चालू करना बाकी है। स्विच ग्रे हो तो नीचे 'ज़रूरी नोट' देखें।"
            }
            !pm.isIgnoringBatteryOptimizations(packageName) -> {
                if (asked.add("batt")) startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                else startVoice()
            }
            else -> startVoice()
        }
    }

    private fun startVoice() {
        val w = getSharedPreferences("p", MODE_PRIVATE).getString("wake", "मेरे दोस्त")
        if (!VoiceService.active)
            startForegroundService(Intent(this, VoiceService::class.java).putExtra("wake", w))
        status.text = "🎙️ चालू है! अब ऐप बंद करके बोलें:\n\"$w, यूट्यूब चलाओ, एक गाना चलाओ, फुल स्क्रीन करो, आवाज़ 20 करो\""
    }
}
