package com.example.voicecontrol

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.provider.CallLog
import android.provider.ContactsContract

object PhoneInfo {
    // slot 0 = सिम 1, slot 1 = सिम 2. दो सिम न हों तो null
    fun simHandle(ctx: Context, slot: Int): PhoneAccountHandle? {
        if (ctx.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            val handles = tm.callCapablePhoneAccounts
            if (handles.size < 2) return null
            var chosen: PhoneAccountHandle? = null
            if (Build.VERSION.SDK_INT >= 30) {
                val sm = ctx.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
                val subs = sm.activeSubscriptionInfoList ?: emptyList()
                val tel = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
                for (hd in handles) {
                    val subId = tel.createForPhoneAccountHandle(hd)?.subscriptionId ?: continue
                    if (subs.firstOrNull { it.subscriptionId == subId }?.simSlotIndex == slot) { chosen = hd; break }
                }
            }
            chosen ?: handles.getOrNull(slot)
        } catch (e: Exception) { null }
    }

    fun nameFor(ctx: Context, num: String): String {
        if (num.isBlank()) return "अनजान नंबर"
        return try {
            ctx.contentResolver.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "अनजान नंबर"
        } catch (e: Exception) { "अनजान नंबर" }
    }

    fun battery(ctx: Context) {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val st = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = st?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        Speaker.say(ctx, "बैटरी $pct प्रतिशत है" + if (charging) ", और चार्ज हो रही है" else "")
    }

    private data class Row(val num: String, val cached: String?, val type: Int)

    fun calls(ctx: Context, kind: String) {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            Speaker.say(ctx, "कॉल लॉग की अनुमति नहीं है"); return
        }
        val uri = CallLog.Calls.CONTENT_URI.buildUpon()
            .appendQueryParameter(CallLog.Calls.LIMIT_PARAM_KEY, "50").build()
        val rows = mutableListOf<Row>()
        try {
            ctx.contentResolver.query(uri,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE),
                null, null, CallLog.Calls.DATE + " DESC")?.use { c ->
                while (c.moveToNext()) rows.add(Row(c.getString(0) ?: "", c.getString(1), c.getInt(2)))
            }
        } catch (e: Exception) { Speaker.say(ctx, "कॉल लॉग नहीं पढ़ पाया"); return }

        fun nm(r: Row): String = r.cached?.takeIf { it.isNotBlank() } ?: nameFor(ctx, r.num)
        val out = CallLog.Calls.OUTGOING_TYPE
        val inc = CallLog.Calls.INCOMING_TYPE
        val mis = CallLog.Calls.MISSED_TYPE

        when (kind) {
            "missed" -> {
                val names = rows.filter { it.type == mis }.map { nm(it) }.distinct().take(3)
                Speaker.say(ctx, if (names.isEmpty()) "कोई मिस कॉल नहीं है" else "मिस कॉल: " + names.joinToString(", "))
            }
            "in" -> {
                val r = rows.firstOrNull { it.type == inc || it.type == mis || it.type == CallLog.Calls.REJECTED_TYPE }
                Speaker.say(ctx, if (r == null) "कोई आई हुई कॉल नहीं मिली" else "आखिरी कॉल ${nm(r)} की आई थी")
            }
            "out" -> {
                val r = rows.firstOrNull { it.type == out }
                Speaker.say(ctx, if (r == null) "कोई की हुई कॉल नहीं मिली" else "आपने आखिरी कॉल ${nm(r)} को की थी")
            }
            else -> {
                val r = rows.firstOrNull()
                if (r == null) { Speaker.say(ctx, "कॉल लॉग खाली है"); return }
                val n = nm(r)
                Speaker.say(ctx, when (r.type) {
                    out -> "आखिरी कॉल आपने $n को की थी"
                    mis -> "$n की मिस कॉल थी"
                    inc -> "आखिरी कॉल $n की आई थी"
                    else -> "आखिरी कॉल $n से थी"
                })
            }
        }
    }
}
