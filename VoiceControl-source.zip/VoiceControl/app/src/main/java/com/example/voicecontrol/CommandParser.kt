package com.example.voicecontrol

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.MediaStore

data class Step(val key: String, val arg: String = "")

object CommandParser {
    private val defs = listOf(
        "yt" to Regex("यूट्यूब|युट्यूब|youtube"),
        "song" to Regex("गाना|गाने|सॉन्ग|song|भजन"),
        "full" to Regex("फुल\\s*स्क्रीन|फ़ुल\\s*स्क्रीन|full\\s*screen|पूरी\\s*स्क्रीन"),
        "vol" to Regex("आवाज़|आवाज|वॉल्यूम|volume"),
        "wa" to Regex("व्हाट्सएप|व्हाट्सऐप|वॉट्सऐप|whatsapp"),
        "call" to Regex("कॉल|फोन\\s*लगा|call"),
        "google" to Regex("गूगल|google"),
        "home" to Regex("होम|home")
    )
    private val nums = mapOf("दस" to 10, "बीस" to 20, "तीस" to 30, "चालीस" to 40, "पचास" to 50,
        "साठ" to 60, "सत्तर" to 70, "अस्सी" to 80, "नब्बे" to 90, "सौ" to 100)

    fun parse(raw: String): List<Step> {
        val t = raw.lowercase()
        return defs.mapNotNull { (k, re) -> re.find(t)?.let { k to it.range.first } }
            .sortedBy { it.second }
            .map { (k, _) ->
                when (k) {
                    "vol" -> Step(k, (Regex("(\\d{1,3})").find(t)?.value?.toInt()
                        ?: nums.entries.firstOrNull { t.contains(it.key) }?.value ?: 50).coerceIn(0, 100).toString())
                    "song" -> Step(k, Regex("(\\S+)\\s*(?:का|के)\\s*(?:गाना|गाने|भजन)").find(t)
                        ?.groupValues?.get(1)?.let { "$it गाना" } ?: "लोकप्रिय हिंदी गाना")
                    "call" -> Step(k, Regex("(\\S+)\\s*को\\s*(?:कॉल|फोन)").find(t)?.groupValues?.get(1) ?: "")
                    else -> Step(k)
                }
            }
    }

    fun run(ctx: Context, steps: List<Step>) {
        val h = Handler(Looper.getMainLooper())
        var delay = 0L
        for (s in steps) {
            h.postDelayed({ exec(ctx, s) }, delay)
            delay += when (s.key) { "yt" -> 3000L; "song" -> 6000L; else -> 1500L }
        }
    }

    private fun launch(ctx: Context, i: Intent) {
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    private fun exec(ctx: Context, s: Step) {
        when (s.key) {
            "yt" -> ctx.packageManager.getLaunchIntentForPackage("com.google.android.youtube")?.let { launch(ctx, it) }
            "song" -> {
                val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                    .setPackage("com.google.android.youtube")
                    .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                    .putExtra(SearchManager.QUERY, s.arg)
                if (i.resolveActivity(ctx.packageManager) != null) launch(ctx, i)
                else launch(ctx, Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(s.arg))))
            }
            "full" -> ControlAccessibilityService.instance?.goFullscreen()
            "vol" -> {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, max * s.arg.toInt() / 100, AudioManager.FLAG_SHOW_UI)
            }
            "wa" -> ctx.packageManager.getLaunchIntentForPackage("com.whatsapp")?.let { launch(ctx, it) }
            "google" -> launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
            "home" -> launch(ctx, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
            "call" -> {
                val c = ctx.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                    arrayOf("%" + s.arg + "%"), null)
                val num = c?.use { if (it.moveToFirst()) it.getString(0) else null }
                if (num != null) launch(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
            }
        }
    }
}
