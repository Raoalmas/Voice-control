package com.example.voicecontrol

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast

data class Step(val key: String, val arg: String = "")

object CommandParser {
    private val closers = setOf("चलाओ", "खोलो", "करो", "लगाओ", "भेजो", "बजाओ", "दिखाओ", "कीजिए", "खोलिए", "चलाइए")
    private val joiners = setOf("और", "फिर", "then", "and", "उसके", "बाद")
    private val fillers = setOf("खोलो", "चलाओ", "करो", "लगाओ", "भेजो", "बजाओ", "दिखाओ", "कीजिए", "खोलिए", "चलाइए",
        "ओपन", "open", "start", "play", "शुरू", "को", "पर", "में", "एक", "ऐप", "app", "प्लीज", "please",
        "जरा", "ज़रा", "मुझे", "का", "के", "की", "the")
    private val songWords = setOf("गाना", "गाने", "सॉन्ग", "song", "भजन", "गीत", "यूट्यूब", "युट्यूब", "youtube",
        "कोई", "सा", "वाला", "अच्छा", "लोकप्रिय", "नया", "प्ले")
    private val callNoise = setOf("कॉल", "फोन", "लगाओ", "call", "dial", "डायल", "करो", "भेजो", "मेरे", "मेरी", "मेरा", "एक")

    private val fullRe = Regex("फुल\\s*स्क्रीन|फ़ुल\\s*स्क्रीन|full\\s*screen|पूरी\\s*स्क्रीन")
    private val volRe = Regex("आवाज़|आवाज|वॉल्यूम|वाल्यूम|volume|साउंड|sound")
    private val songRe = Regex("गाना|गाने|सॉन्ग|song|भजन|गीत")
    private val callRe = Regex("कॉल|फोन\\s*लगा|call|dial|डायल")
    private val homeRe = Regex("होम|home")
    private val nums = mapOf("दस" to 10, "बीस" to 20, "तीस" to 30, "चालीस" to 40, "पचास" to 50,
        "साठ" to 60, "सत्तर" to 70, "अस्सी" to 80, "नब्बे" to 90, "सौ" to 100)

    private val aliases = listOf(
        "गूगल मैप" to "maps", "मैप" to "maps", "नक्शा" to "maps",
        "प्ले स्टोर" to "play store", "यूट्यूब" to "youtube", "युट्यूब" to "youtube", "youtube" to "youtube",
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "व्हाट्स ऐप" to "whatsapp",
        "कैमरा" to "camera", "गैलरी" to "gallery", "फोटो" to "photos", "सेटिंग" to "settings",
        "कैलकुलेटर" to "calculator", "घड़ी" to "clock", "क्लॉक" to "clock", "अलार्म" to "clock",
        "क्रोम" to "chrome", "गूगल" to "google", "इंस्टाग्राम" to "instagram", "फेसबुक" to "facebook",
        "टेलीग्राम" to "telegram", "स्नैपचैट" to "snapchat", "जीमेल" to "gmail",
        "म्यूजिक" to "music", "संगीत" to "music", "मैसेज" to "messages",
        "संपर्क" to "contacts", "कॉन्टैक्ट" to "contacts", "फाइल" to "files", "नोट" to "notes",
        "कैलेंडर" to "calendar", "डायलर" to "phone", "फोन" to "phone")

    // वाक्य को क्रिया (चलाओ/करो/खोलो...) पर तोड़कर अलग-अलग स्टेप बनाता है
    fun parse(raw: String): List<Step> {
        val tokens = raw.lowercase().replace(Regex("[,।.?!]"), " ").split(Regex("\\s+")).filter { it.isNotEmpty() }
        val clauses = mutableListOf<List<String>>()
        var cur = mutableListOf<String>()
        for (t in tokens) {
            if (t in joiners) { if (cur.isNotEmpty()) { clauses.add(cur); cur = mutableListOf() }; continue }
            cur.add(t)
            if (t in closers) { clauses.add(cur); cur = mutableListOf() }
        }
        if (cur.isNotEmpty()) clauses.add(cur)
        return clauses.mapNotNull { classify(it) }
    }

    private fun classify(c: List<String>): Step? {
        val text = c.joinToString(" ")
        return when {
            fullRe.containsMatchIn(text) -> Step("full")
            volRe.containsMatchIn(text) -> Step("vol", vol(text))
            songRe.containsMatchIn(text) -> Step("song", songArg(c))
            callRe.containsMatchIn(text) -> Step("call", callName(c))
            homeRe.containsMatchIn(text) -> Step("home")
            else -> {
                val name = c.filter { it !in fillers }.joinToString(" ")
                if (name.isBlank()) null else Step("app", name)
            }
        }
    }

    private fun vol(t: String): String {
        Regex("(\\d{1,3})").find(t)?.let { return it.value.toInt().coerceIn(0, 100).toString() }
        nums.entries.firstOrNull { t.contains(it.key) }?.let { return it.value.toString() }
        return when {
            Regex("म्यूट|mute").containsMatchIn(t) -> "0"
            Regex("बढ़ा|बढा|ज्यादा|ज़्यादा|तेज|up").containsMatchIn(t) -> "+20"
            Regex("घटा|कम|धीमी|धीरे|down").containsMatchIn(t) -> "-20"
            else -> "50"
        }
    }

    private fun songArg(c: List<String>): String {
        val rest = c.filter { it !in fillers && it !in songWords }.joinToString(" ")
        val bhajan = c.contains("भजन")
        return if (rest.isBlank()) (if (bhajan) "भजन" else "लोकप्रिय हिंदी गाना")
        else rest + (if (bhajan) " भजन" else " गाना")
    }

    private fun callName(c: List<String>): String {
        val i = c.indexOf("को")
        val base = if (i > 0) c.subList(0, i) else c
        return base.filter { it !in callNoise && it !in fillers }.joinToString(" ")
    }

    fun run(ctx: Context, steps: List<Step>) {
        val h = Handler(Looper.getMainLooper())
        var t = 0L
        for (s in steps) {
            h.postDelayed({ exec(ctx, s) }, t)
            t += when (s.key) { "app" -> 2500L; "song" -> 6000L; else -> 1200L }
        }
    }

    private fun toast(ctx: Context, m: String) =
        Toast.makeText(ctx.applicationContext, m, Toast.LENGTH_SHORT).show()

    private fun launch(ctx: Context, i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { toast(ctx, "खुल नहीं पाया: ${e.javaClass.simpleName}"); false }

    private fun openApp(ctx: Context, name: String) {
        val n = name.lowercase().trim()
        val key = aliases.firstOrNull { n.contains(it.first) }?.second ?: n
        when (key) {
            "camera" -> { launch(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); return }
            "settings" -> { launch(ctx, Intent(Settings.ACTION_SETTINGS)); return }
            "phone" -> { launch(ctx, Intent(Intent.ACTION_DIAL)); return }
        }
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == key }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(key) }
        val li = hit?.activityInfo?.packageName?.let { pm.getLaunchIntentForPackage(it) }
        if (li != null) launch(ctx, li) else toast(ctx, "ऐप नहीं मिला: $name")
    }

    private fun exec(ctx: Context, s: Step) {
        when (s.key) {
            "app" -> openApp(ctx, s.arg)
            "song" -> {
                val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                    .setPackage("com.google.android.youtube")
                    .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                    .putExtra(SearchManager.QUERY, s.arg)
                if (i.resolveActivity(ctx.packageManager) != null) launch(ctx, i)
                else launch(ctx, Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(s.arg))))
            }
            "full" -> {
                val a = ControlAccessibilityService.instance
                if (a != null) a.goFullscreen() else toast(ctx, "Accessibility चालू नहीं है")
            }
            "vol" -> {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val d = max * s.arg.toInt() / 100
                val t = if (s.arg.startsWith("+") || s.arg.startsWith("-"))
                    am.getStreamVolume(AudioManager.STREAM_MUSIC) + d else d
                am.setStreamVolume(AudioManager.STREAM_MUSIC, t.coerceIn(0, max), AudioManager.FLAG_SHOW_UI)
            }
            "home" -> launch(ctx, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
            "call" -> {
                if (s.arg.isBlank()) { toast(ctx, "किसे कॉल करना है? नाम भी बोलें"); return }
                val c = ctx.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                    arrayOf("%" + s.arg + "%"), null)
                val num = c?.use { if (it.moveToFirst()) it.getString(0) else null }
                if (num != null) launch(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
                else toast(ctx, "संपर्क नहीं मिला: ${s.arg}")
            }
        }
    }
}
