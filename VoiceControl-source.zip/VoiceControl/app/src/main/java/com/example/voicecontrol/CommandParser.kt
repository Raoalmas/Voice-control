package com.example.voicecontrol

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.widget.Toast

data class Step(val key: String, val arg: String = "", val sim: Int = -1)

object CommandParser {
    private val closers = setOf("चलाओ", "खोलो", "करो", "लगाओ", "भेजो", "बजाओ", "दिखाओ", "कीजिए", "खोलिए", "चलाइए",
        "बताओ", "बताइए", "सुनाओ")
    private val joiners = setOf("और", "फिर", "then", "and", "उसके", "बाद")
    private val stems = setOf("कर", "खोल", "चला", "बजा", "लगा", "भेज", "दिखा")
    private val fillers = setOf("खोलो", "चलाओ", "करो", "लगाओ", "भेजो", "बजाओ", "दिखाओ", "कीजिए", "खोलिए", "चलाइए",
        "बताओ", "बताइए", "सुनाओ", "ओपन", "open", "start", "play", "शुरू", "को", "पर", "में", "एक", "ऐप", "app",
        "प्लीज", "please", "जरा", "ज़रा", "मुझे", "का", "के", "की", "the", "कर", "दो", "दीजिए", "जी", "तो", "ना",
        "खोल", "चला", "karo", "kro", "kholo", "chalao", "lagao", "kar", "do", "launch", "run", "ko", "par", "me",
        "mein", "ek")
    private val songWords = setOf("गाना", "गाने", "सॉन्ग", "song", "भजन", "गीत", "यूट्यूब", "युट्यूब", "youtube",
        "कोई", "सा", "वाला", "अच्छा", "लोकप्रिय", "नया", "प्ले")
    private val callNoise = setOf("कॉल", "फोन", "लगाओ", "call", "dial", "डायल", "करो", "भेजो", "मेरे", "मेरी", "मेरा",
        "एक", "सिम", "sim", "वन", "टू", "तू", "one", "two", "से", "1", "2", "१", "२", "पहली", "दूसरी", "first", "second")

    private val fullRe = Regex("फुल\\s*स्क्रीन|फ़ुल\\s*स्क्रीन|full\\s*screen|पूरी\\s*स्क्रीन")
    private val volRe = Regex("आवाज़|आवाज|वॉल्यूम|वाल्यूम|volume|साउंड|sound")
    private val songRe = Regex("गाना|गाने|सॉन्ग|song|भजन|गीत")
    private val callRe = Regex("कॉल|फोन\\s*लगा|call|dial|डायल")
    private val homeRe = Regex("होम|home")
    private val batRe = Regex("बैटरी|battery|चार्ज")
    private val missRe = Regex("मिस|missed")
    private val inRe = Regex("आई\\s*थी|आया\\s*था|किसकी|इनकमिंग|incoming|कॉल\\s*आई|आई\\s*है")
    private val outRe = Regex("किसे|किसको|किसके\\s*पास|आउटगोइंग|outgoing|कॉल\\s*की\\s*थी|कॉल\\s*किया")
    private val lastRe = Regex("आखिरी|आख़िरी|लास्ट|last|पिछली|पिछला")
    private val sim1Re = Regex("(सिम|sim)\\s*(1|१|वन|एक|one)|पहली\\s*सिम|first\\s*sim")
    private val sim2Re = Regex("(सिम|sim)\\s*(2|२|टू|तू|दो|two)|दूसरी\\s*सिम|second\\s*sim")
    private val pickRe = Regex("नंबर|नम्बर|number|पहला|पहली|दूसरा|दूसरी|तीसरा|तीसरी|चौथा|चौथी|पांचवा|पाँचवा|पांचवां|पाँचवाँ|छठा|first|second|third|fourth|fifth")
    private val vidRe = Regex("वीडियो|video|वाला|वाली|वाले|चलाओ|play")
    private val ordinals = mapOf(
        "एक" to 1, "पहला" to 1, "पहली" to 1, "first" to 1, "one" to 1, "वन" to 1,
        "दो" to 2, "दूसरा" to 2, "दूसरी" to 2, "second" to 2, "two" to 2, "टू" to 2,
        "तीन" to 3, "तीसरा" to 3, "तीसरी" to 3, "third" to 3, "three" to 3, "थ्री" to 3,
        "चार" to 4, "चौथा" to 4, "चौथी" to 4, "fourth" to 4, "four" to 4, "फोर" to 4,
        "पांच" to 5, "पाँच" to 5, "पांचवा" to 5, "पाँचवा" to 5, "पांचवां" to 5, "पाँचवाँ" to 5, "fifth" to 5, "five" to 5,
        "छह" to 6, "छः" to 6, "छे" to 6, "छठा" to 6, "six" to 6, "सात" to 7, "seven" to 7,
        "आठ" to 8, "eight" to 8, "नौ" to 9, "nine" to 9, "दस" to 10, "ten" to 10)
    private val nums = mapOf("दस" to 10, "बीस" to 20, "तीस" to 30, "चालीस" to 40, "पचास" to 50,
        "साठ" to 60, "सत्तर" to 70, "अस्सी" to 80, "नब्बे" to 90, "सौ" to 100)

    // जिन नामों का अंग्रेज़ी ऐप-नाम से सीधा मेल नहीं बैठता
    private val aliases = listOf(
        "गूगल मैप" to "maps", "नक्शा" to "maps", "गैलरी" to "gallery", "फोटो" to "photos",
        "सेटिंग" to "settings", "घड़ी" to "clock", "अलार्म" to "clock", "संगीत" to "music",
        "संपर्क" to "contacts", "डायलर" to "phone", "फोन" to "phone", "कैमरा" to "camera", "camera" to "camera")

    // वाक्य को क्रिया (चलाओ/करो/खोलो...) पर तोड़कर अलग-अलग स्टेप बनाता है
    fun parse(raw: String): List<Step> {
        val tokens = raw.lowercase().replace(Regex("[,।.?!]"), " ").split(Regex("\\s+")).filter { it.isNotEmpty() }
        val clauses = mutableListOf<List<String>>()
        var cur = mutableListOf<String>()
        for (t in tokens) {
            if (t in joiners) { if (cur.isNotEmpty()) { clauses.add(cur); cur = mutableListOf() }; continue }
            cur.add(t)
            if (t in closers || (t == "दो" && cur.size >= 2 && cur[cur.size - 2] in stems)) {
                clauses.add(cur); cur = mutableListOf()
            }
        }
        if (cur.isNotEmpty()) clauses.add(cur)
        return clauses.mapNotNull { classify(it) }
    }

    private fun pickNum(c: List<String>): Int? {
        for (t in c) Regex("^\\d+$").find(t)?.let { return it.value.toInt() }
        for (t in c) ordinals[t]?.let { return it }
        return null
    }

    private fun simOf(t: String): Int = when {
        sim1Re.containsMatchIn(t) -> 0
        sim2Re.containsMatchIn(t) -> 1
        else -> -1
    }

    private fun classify(c: List<String>): Step? {
        val text = c.joinToString(" ")
        return when {
            fullRe.containsMatchIn(text) -> Step("full")
            volRe.containsMatchIn(text) -> Step("vol", vol(text))
            batRe.containsMatchIn(text) -> Step("battery")
            callRe.containsMatchIn(text) || missRe.containsMatchIn(text) -> when {
                missRe.containsMatchIn(text) -> Step("calls", "missed")
                inRe.containsMatchIn(text) -> Step("calls", "in")
                lastRe.containsMatchIn(text) && outRe.containsMatchIn(text) -> Step("calls", "out")
                lastRe.containsMatchIn(text) -> Step("calls", "last")
                outRe.containsMatchIn(text) -> Step("calls", "out")
                else -> Step("call", callName(c), simOf(text))
            }
            pickRe.containsMatchIn(text) && vidRe.containsMatchIn(text) && pickNum(c) != null ->
                Step("pick", pickNum(c).toString())
            songRe.containsMatchIn(text) -> Step("song", songArg(c))
            homeRe.containsMatchIn(text) -> Step("home")
            else -> {
                val name = c.filter { it !in fillers }.joinToString(" ")
                if (name.isBlank()) null else Step("app", name)
            }
        }
    }

    private fun vol(t: String): String {
        Regex("(\\d{1,3})").find(t)?.let { return it.value.toInt().coerceIn(0, 100).toString() }
        nums.entries.firstOrNull { t.contains(it.key) }?.let { return it.value.toString() }
        return when {
            Regex("म्यूट|mute").containsMatchIn(t) -> "0"
            Regex("बढ़ा|बढा|ज्यादा|ज़्यादा|तेज|up").containsMatchIn(t) -> "+20"
            Regex("घटा|कम|धीमी|धीरे|down").containsMatchIn(t) -> "-20"
            else -> "50"
        }
    }

    private fun songArg(c: List<String>): String {
        val rest = c.filter { it !in fillers && it !in songWords }.joinToString(" ")
        val bhajan = c.contains("भजन")
        return if (rest.isBlank()) (if (bhajan) "भजन" else "लोकप्रिय हिंदी गाना")
        else rest + (if (bhajan) " भजन" else " गाना")
    }

    private fun callName(c: List<String>): String {
        val i = c.indexOf("को")
        val base = if (i > 0) c.subList(0, i) else c
        return base.filter { it !in callNoise && it !in fillers }.joinToString(" ")
    }

    fun run(ctx: Context, steps: List<Step>) {
        val h = Handler(Looper.getMainLooper())
        var t = 0L
        steps.forEachIndexed { i, s ->
            h.postDelayed({ exec(ctx, s) }, t)
            val nx = steps.getOrNull(i + 1)?.key
            t += when (s.key) {
                "app" -> if (nx == "song" || nx == "full" || nx == "pick") 2200L else 900L
                "song" -> if (nx == "full") 4500L else 900L
                "pick" -> if (nx == "full") 3500L else 900L
                "call", "calls", "battery" -> 3000L
                else -> 900L
            }
        }
    }

    private fun toast(ctx: Context, m: String) =
        Toast.makeText(ctx.applicationContext, m, Toast.LENGTH_SHORT).show()

    private fun launch(ctx: Context, i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { toast(ctx, "खुल नहीं पाया: ${e.javaClass.simpleName}"); false }

    private fun openApp(ctx: Context, name: String) {
        val n = name.lowercase().trim()
        val key = aliases.firstOrNull { n.contains(it.first) }?.second ?: n
        when (key) {
            "camera" -> { Speaker.say(ctx, "कैमरा खोल रहा हूँ"); launch(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); return }
            "settings" -> { Speaker.say(ctx, "सेटिंग खोल रहा हूँ"); launch(ctx, Intent(Settings.ACTION_SETTINGS)); return }
            "phone" -> { Speaker.say(ctx, "फोन खोल रहा हूँ"); launch(ctx, Intent(Intent.ACTION_DIAL)); return }
        }
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == key }
            ?: Phonetic.best(Phonetic.skel(key), apps.map { it to Phonetic.skel(it.loadLabel(pm).toString()) })
        val li = hit?.activityInfo?.packageName?.let { pm.getLaunchIntentForPackage(it) }
        if (hit != null && li != null) {
            Speaker.say(ctx, "${hit.loadLabel(pm)} खोल रहा हूँ")
            launch(ctx, li)
        } else Speaker.say(ctx, "ऐप नहीं मिला: $name")
    }

    private fun findContact(ctx: Context, name: String): Pair<String, String>? {
        val items = mutableListOf<Pair<Pair<String, String>, String>>()
        ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                items.add((n to num) to Phonetic.skel(n))
            }
        }
        return Phonetic.best(Phonetic.skel(name), items)
    }

    private fun exec(ctx: Context, s: Step) {
        when (s.key) {
            "app" -> openApp(ctx, s.arg)
            "song" -> {
                Speaker.say(ctx, "${s.arg} चला रहा हूँ")
                val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                    .setPackage("com.google.android.youtube")
                    .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                    .putExtra(SearchManager.QUERY, s.arg)
                if (i.resolveActivity(ctx.packageManager) != null) launch(ctx, i)
                else launch(ctx, Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(s.arg))))
            }
            "pick" -> {
                val a = ControlAccessibilityService.instance
                if (a != null) a.pickVideo(s.arg.toInt()) else Speaker.say(ctx, "Accessibility चालू नहीं है")
            }
            "full" -> {
                val a = ControlAccessibilityService.instance
                if (a != null) { Speaker.say(ctx, "फुल स्क्रीन कर रहा हूँ"); a.goFullscreen() }
                else Speaker.say(ctx, "Accessibility चालू नहीं है")
            }
            "vol" -> {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val d = max * s.arg.toInt() / 100
                val t = (if (s.arg.startsWith("+") || s.arg.startsWith("-"))
                    am.getStreamVolume(AudioManager.STREAM_MUSIC) + d else d).coerceIn(0, max)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, t, AudioManager.FLAG_SHOW_UI)
                Speaker.say(ctx, "आवाज़ ${if (max > 0) t * 100 / max else 0} प्रतिशत कर दी")
            }
            "home" -> { Speaker.say(ctx, "होम पर जा रहा हूँ"); launch(ctx, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)) }
            "battery" -> PhoneInfo.battery(ctx)
            "calls" -> PhoneInfo.calls(ctx, s.arg)
            "call" -> {
                if (s.arg.isBlank()) { Speaker.say(ctx, "किसे कॉल करना है? नाम भी बोलें"); return }
                val hit = findContact(ctx, s.arg)
                if (hit == null) { Speaker.say(ctx, "संपर्क नहीं मिला: ${s.arg}"); return }
                val handle = if (s.sim >= 0) PhoneInfo.simHandle(ctx, s.sim) else null
                val via = when {
                    s.sim < 0 -> ""
                    handle != null -> " सिम ${s.sim + 1} से"
                    else -> ", सिम ${s.sim + 1} नहीं मिली, सामान्य सिम से"
                }
                Speaker.say(ctx, "${hit.first} को$via कॉल लगा रहा हूँ")
                val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(hit.second)))
                if (handle != null) i.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, handle)
                launch(ctx, i)
            }
        }
    }
}
